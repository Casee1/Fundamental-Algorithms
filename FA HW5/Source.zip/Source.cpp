#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include "Profiler.h"
#include <cstring>
#define c1 1
#define c2 2
#define n 21
#define n1 10007

using namespace std;
Profiler profiler("test");

//#define M 10
//#define EMPTY -1
//int hTable[M];
//
//int h(int size, int i) {
//    return (i * i + i * 2 + 1) % size;
//}
//
//// Returns 1 if found, 0 otherwise
//int find(int x) {
//    int i = 0;
//    while (i < M && hTable[h(x, i)] != x && hTable[h(x, i)] != EMPTY)
//        i++;
//    if (i == M || hTable[h(x, i)] == EMPTY)
//        return 0;
//    return 1;
//}
//
//void insert(int x) {
//    int i = 0;
//    while (hTable[h(x, i)] != EMPTY && i < M)
//        i++;
//    if (i < M)
//        hTable[h(x, i)] = x;
//}
//
//void printHash() {
//    printf("The hash table looks like:\n");
//    for (int i = 0; i < M; i++) {
//        printf("-----");
//    }
//    printf("-\n|");
//    for (int i = 0; i < M; i++) {
//        printf(" %2d |", i);
//    }
//    printf("\n");
//    for (int i = 0; i < M; i++) {
//        printf("-----");
//    }
//    printf("-\n|");
//    for (int i = 0; i < M; i++) {
//        printf(" %2d |", hTable[i]);
//    }
//    printf("\n");
//    for (int i = 0; i < M; i++) {
//        printf("-----");
//    }
//    printf("-\n");
//}
//
//int main() {
//    for (int i = 0; i < M; i++) {
//        hTable[i] = EMPTY;
//    }
//
//    insert(12);
//    insert(37);
//    insert(22);
//    printHash();
//
//    printf("find(22) returns: %d\n", find(22));
//    printf("find(32) returns: %d\n", find(32));
//    printf("find(37) returns: %d\n", find(37));
//}

typedef struct entry
{
	int id;
	char value[30] = "empty";
}Entry;
int hash_functiondemo(int key, int i)
{
	if (n != 0)
		return (key + c1 * i + c2 * i * i) % n;
}
int hash_function(int key, int i)
{
	if (n != 0)
		return (key + c1 * i + c2 * i * i) % n1;
}
void initialization(Entry table[], int size)
{
	for (int i = 0; i < size; i++)
	{
		strcpy(table[i].value, "empty"); //here I initializate the table and set the all keys to be 0 and the name "empty"
		table[i].id = 0;
	}
}

void insert(Entry table[], int key, const char name[]) //we examine the hash until we find an empty place and put the key and the name 
{
	int i = 0;
	do
	{
		int j = hash_function(key, i);
		if (!strcmp(table[j].value, "empty") && table[j].id == NULL)
		{
			table[j].id = key;
			strcpy(table[j].value, name);
			return;
		}
		else
		{
			i++;
		}
	} while (i != n1);
	return;
}
void insertdemo(Entry table[], int key, const char name[]) //insertion for the demo, it's the same like the previous one 
{
	int i = 0;
	do
	{
		int j = hash_functiondemo(key, i);
		if (!strcmp(table[j].value, "empty") && table[j].id == NULL)
		{
			table[j].id = key;
			strcpy(table[j].value, name);
			//cout << j << " ";
			return;
		}
		else
		{
			i++;
		}
	} while (i != n);
	return;
}

int find(Entry table[], int key, int& colisions) //returning j if it finds that slot j contains the key, or NIL if key k is not present in table
{
	colisions = 0;
	int j;
	do
	{
		j = hash_function(key, colisions);
		colisions++;
		if (table[j].id == key)
		{
			return j;
		}
		//cout << colisions << " ";
	} while (!strcmp(table[j].value, "empty") || colisions == n1);
	return -1;
}
int finddemo(Entry table[], int key)

{
	int i = 0;
	int j;
	do
	{
		j = hash_functiondemo(key, i);
		if (table[j].id == key)
		{
			return j;
		}
		i++;
	} while (i != n);
	return -1;
}

void demo()
{
	Entry table1[n];
	initialization(table1, n);
	insertdemo(table1, 4, "Giulia");
	insertdemo(table1, 26, "Teodora");
	insertdemo(table1, 15, "Sorin");
	insertdemo(table1, 10, "Darius");
	for (int i = 0; i < n; i++)
	{
		cout << i << ": " << table1[i].value << " " << table1[i].id;
		cout << endl;
	}

	cout << endl;
	int key;
	cout << "The key is: ";
	cin >> key;
	if (finddemo(table1, key) != -1)
	{
		cout << table1[finddemo(table1, key)].value << " " << table1[finddemo(table1, key)].id;
	}
	else
		cout << "Didn't found";

}

void fill_factor1(float fill_factor, Entry table[])
{
	int aux[n1];
	FillRandomArray(aux, n1, 1000000, 1000000000, true, UNSORTED);
	int nr_elem = n1 * fill_factor;
	for (int i = 0; i < nr_elem; i++)
	{
		insert(table, aux[i], "INSERTED");
	}
	/*for (int i = 0; i < n; i++)
	{
		cout << table[i].id << " ";
	}*/
	for (int i = nr_elem; i <= n1; i++)
	{
		int pos = rand() % n1;
		while (table[pos].id == 0)
		{
			pos = rand() % n1;
		}
		table[pos].id = 0;
		strcpy(table[pos].value, "empty");
	}
	/*for (int i = 0; i < n1; i++)
	{
		cout << table[i].id << " ";
	}*/
	int total_effort = 0;
	/*find(table, table[7002].id, total_effort);
	cout << table[7002].id<<" "<<total_effort;*/

	int max_effort = -1;
	for (int i = 1; i <= 1500; i++)
	{
		int colisions = 0;
		int pos = rand() % n1;
		while (table[pos].id == NULL)
		{
			pos = rand() % n1;
		}
		find(table, table[pos].id, colisions);
		if (max_effort < colisions)
		{
			max_effort = colisions;
		}
		total_effort = total_effort + colisions;
	}
	cout << "Total nr of effort is: " << total_effort << " and the nr of max effort is: " << max_effort;
}

int main()
{
	//demo();
	Entry table[n1] = {};
	fill_factor1(0.8, table);
	cout << endl;
	fill_factor1(0.85, table);
	cout << endl;
	fill_factor1(0.9, table);
	cout << endl;
	fill_factor1(0.95, table);
	cout << endl;
	fill_factor1(0.99, table);


}