/*
 *      Pentru a doua transformare, intai am creat prima ramura a arborelui, inserand primul copil al fiecarui nod. Cand am ajuns
 *  la un nod fara copii, am inceput sa apelez recursiv functia pentru fratii nodului respectiv. Aceasta functie nu foloseste memorie
 *  aditionala.
 */
#include <iostream>
using namespace std;

  
//typedef struct node_type
//{
//	int id;
//	struct node_type* left, * right;
//} NodeT;
//void preorder(NodeT* p, int level)
//{
//	if (p != NULL)
//	{
//		for (int i = 0; i <= level; i++) printf(" ");
//		printf("%2.2d\n", p->id);
//		preorder(p->left, level + 1);
//		preorder(p->right, level + 1);
//	}
//}
//NodeT* createNode(int id, NodeT* left, NodeT* right)
//{
//	NodeT* newNode = (NodeT*)malloc(sizeof(NodeT));
//	newNode->id = id;
//	newNode->left = left;
//	newNode->right = right;
//	return newNode;
//}
//int main()
//{
//	NodeT* root = createNode(1,
//		createNode(7,
//			createNode(2,
//				NULL,
//				createNode(5, NULL, NULL)),
//			NULL),
//		createNode(9,
//			createNode(3, NULL, NULL),
//			createNode(4,
//				NULL,
//				createNode(6, NULL, NULL))));
//	printf("\nPreorder listing\n");
//	preorder(root, 0); 

//typedef struct Node2 {
//	int key;
//	struct Node2* next;
//} Node;
//
//typedef struct List2 {
//	Node* head;
//	Node* tail;
//} List;
//
//int visited[10];
//void DFS(List neighb[], int p)
//{
//	visited[p] = 1;
//	printf("%d ", p);
//	// Take each neighbor x
//	Node* x = neighb[p].head;
//	while (x != NULL)
//	{
//		if (visited[x->key] == 0)
//		{
//			visited[x->key] = 1;
//			DFS(neighb, x->key);
//		}
//		x = x->next;
//	}
//}

void R1(int* arr, int size, int root, int level)
{
	for (int i = 0; i < size; i++) //we go throw the whole array
	{
		if (arr[i] == root) // we are looking for the root in the vector
		{
			int j = 0; 
			while (j < level) //spaces
			{
				cout << "    ";
				j++;
			}
			cout << i + 1 << endl; // I print i+1 because I started from the 0 not from the 1
			R1(arr, size, i + 1, level + 1); //we are doing it recursively
		}
	}
}
void demoR1()
{
	int v[] = { 2,7,5,2,7,7,-1,5,2 };
	          //0,1,2,3,4,5,6,7,8
	int size = sizeof(v) / sizeof(v[0]);
	cout << "The parent vector is: ";
	for (int i = 0; i < size; i++)
	{
		cout << v[i] << " "; //parent vector
	}
	cout << endl; 
	cout << "The pretty print for the parent vector is : ";
	cout << endl;
	R1(v, size, -1, 0); //pretty-print
}

typedef struct R2 //for R2 we need the value the size and an array of children
{
	int value;
	int size;
	R2* children[100]; 
}NodeR2;

NodeR2* T1(int* v, int size)
{
	NodeR2* child, * parent, * arr[100];
	NodeR2* first = 0;
	for (int i = 0; i < size; i++)
	{
		arr[i] = (NodeR2*)malloc(sizeof(NodeR2)); //allocate
		arr[i]->size = NULL; //blank nodes 
		arr[i]->value = i + 1;
	}
	for (int j = 0; j < size; j++)
	{
		if (v[j] != -1)  // if is not existing a root
		{
			child = arr[j];  //we increase the counter
			parent = arr[v[j] - 1];
			parent->children[parent->size] = child;
			parent->size++;
		}
		else
		{
			first = arr[j]; //put that value in the root
		}
	}
	return first;
}

int PP_R2(R2* Node, int level)
{
	if (Node == 0)
	{
		return 0;
	}
	else
	{
		for (int j = 0; j < level;j++) //make the spaces
		{
			cout << "    ";
		}
		cout << Node->value << endl;
		for (int i = 0; i < Node->size; i++)
		{
			PP_R2(Node->children[i], level + 1);
		}
	}
}

typedef struct R3
{
	int value;
	struct R3* left; //copilul din stanga
	struct R3* right; // right sibbl
}NodeR3;

NodeR3* T2(NodeR2* first)  //depth
{                      
	NodeR3* j, * R3_node;
	R3_node = (NodeR3*)malloc(sizeof(NodeR3)); //allocate
	R3_node->value = first->value; //takes value of the key root
	R3_node->left = NULL; 
	R3_node->right = NULL;  
	if (first->size > 0) //create the first branch of the tree by putting every child of every node  
	{
		R3_node->left = T2(first->children[0]);
		j = R3_node->left;  
		for (int i = 1; i < first->size; i++)
		{
			j->right = T2(first->children[i]);  //when I get a node without child I started to call recursively the function for the brothers of the respectiv node
			j = j->right;
		}
	}
	return R3_node;
}

int PP_R3(NodeR3* node, int level) 
{
	if (node == NULL)
		return 0;
	else
	{
		for (int i = 0; i < level; i++) //here we create the spaces
		{
			cout << "    ";
		}
		cout << node->value << endl;
		node = node->left;
		while (node != NULL)
		{
			PP_R3(node, level + 1);
			node = node->right;
		}
	}
}


void demoR2()
{
	int v[] = {2,7,5,2,7,7,-1,5,2}; 
	         //0,1,2,3,4,5,6,7,8
	int size = sizeof(v) / sizeof(v[0]);
	NodeR2* root = T1(v, size);
	PP_R2(root, 0);
}
void demoR3()
{
	int v[] = {2,7,5,2,7,7,-1,5,2 };
	         //0,1,2,3,4,5,6,7,8
	int size = sizeof(v) / sizeof(v[0]);
	NodeR2* root = T1(v, size);
	NodeR3* R3_node = T2(root);
	PP_R3(R3_node, 0);
}

int main()
{
	demoR1();
	cout << endl;
	cout << "The pretty print for multiway tree is: ";
	cout << endl;
	demoR2();
	cout << endl;
	cout << "The pretty print for binary tree is: ";
	cout << endl;
	demoR3();
}